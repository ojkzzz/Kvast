jQuery(function ($) {
  $("input[type='tel']").mask("+7 (999) 999-9999");
});
